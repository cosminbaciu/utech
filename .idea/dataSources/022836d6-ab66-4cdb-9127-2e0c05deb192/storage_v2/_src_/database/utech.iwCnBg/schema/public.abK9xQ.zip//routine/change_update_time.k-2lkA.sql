create function change_update_time() returns trigger
  language plpgsql
as
$$
BEGIN
                NEW.updated_at := now();
                RETURN NEW;
            END;
$$;

alter function change_update_time() owner to cosmin;

